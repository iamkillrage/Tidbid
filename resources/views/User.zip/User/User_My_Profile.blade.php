@extends('User.LayoutWebsite.masterwebsite')
@section('content')
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
  <title>User My Profile | TidBid</title>
</head>

<body>

  <!-- Header-Section -->
  <header>
    @include('User.Navbar.nav')
  </header>
  <!-- Header-Section -->

  <!-- Main-Section -->
  <main>

    <div class="prof_lefsect">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="profile_left">
              <ul>

                <li class="{{ request()->is('user-my-profile') ? 'pro_active' : '' }}">
                  <img src="{{ asset('Influencer/images/my-profile.svg') }}">
                  <a href="{{ route('User_Profile') }}">My Profile</a>
                </li>

                <li class="{{ request()->is('user-no-save-card') ? 'pro_active' : '' }}">
                  <img src="{{asset('Influencer/images/Payment.svg')}}">
                  <a href="{{route('UserNoSaveCard')}}">Payment Method</a>
                </li>

                <li class="{{ request()->is('user-my-transactions') ? 'pro_active' : '' }}">
                  <img src="{{asset('Influencer/images/Payment.svg')}}">
                  <a href="{{route('UserMyTransactions')}}">My Transactions</a>
                </li>

                <li class="{{ request()->is('user-refer-friends') ? 'pro_active' : '' }}">
                  <img src="{{asset('Influencer/images/Refer.svg')}}">
                  <a href="{{route('UserReferFriends')}}">Refer A Friend</a>
                </li>
                <li>
                  <img src="{{asset('Influencer/images/chat.svg') }}">
                  <a href="{{url('user-chat/self')}}">Chats</a>
                </li>


                <li class="{{ request()->is('user-bookmark') ? 'pro_active' : '' }}">
                  <img src="{{asset('Influencer/images/bookmark.png')}}">
                  <a href="{{route('UserBookmark')}}">Bookmarks</a>
                </li>

                <li>
                  <img src="{{asset('Influencer/images/logout.svg')}}">
                  <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal_3">Logout</a>
                </li>

              </ul>


            </div>

            <div class="left_pinkbg">
              <div class="people_img"><img src="{{asset('Influencer/images/People-img.png')}}"></div>
              <p>View People you follow</p>
              <a href="{{route('UserFollowing')}}">My Following</a>

            </div>
          </div>

          <div class="col-lg-9 col-md-8 col-sm-12">
            @if (session('success'))
            <script>
              toastr.success('Profile updated successfully!');
            </script>
            @endif

            @if (session('error'))
            <script>
              toastr.error('An error occurred while updating profile details..');
            </script>
            @endif
            <div class="pro_right">
              <!-- <div class="pro_head">Please complete your Profile</div> -->
              @if($useralldeatils->name =='' && $useralldeatils->phone =='' && $useralldeatils->dob =='')
              <div class="pro_head">Please complete your Profile</div>
              @else
              <div class="pro_head">Profile</div>
              @endif

              <form id="#completeprofile" method="POST" action="{{route('User_My_Profile_Create')}}" enctype="multipart/form-data">
                @csrf
                <input type="file" name="profile_img"  id="image_input" style="display: none;">
                <input type="hidden" name="id" value="{{ $useralldeatils->id }}">

                <div class="probox">
                  <div class="prof_img">
                    @if(!empty($useralldeatils->profile_img))
                    <img id="preview_image" src="{{asset('/Influencer/images/profile_img/'.$useralldeatils->profile_img)}}" name="profile_img" class="preview-circle">
                    @else
                    <img src="{{asset('user.jpg')}}" class="preview-circle" id="preview_image">
                    @endif
                  </div>
                  <a href="#" id="upload_icon" class="upload_icon"><img src="{{asset('Influencer/images/upload.png')}}"></a>
                </div>
                @error('profile_img')
                <span class="text-danger">{{ $message }}</span>
                @enderror


                <div class="pro_filed">
                  <div class="form_icon"><img src="{{asset('Influencer/images/person.svg')}}"></div>
                  <input type="text" name="name" required id="name" value="{{$useralldeatils->name}}" placeholder="Full Name">
                </div>
                @error('name')
                <span class="text-danger">{{ $message }}</span>
                @enderror

                <div class="pro_filed">
                  <div class="form_icon"><img src="{{asset('Influencer/images/mail.png')}}"></div>
                  <input type="text" name="email" required value="{{$useralldeatils->email}}" placeholder="Tidbid@gmail.com">
                </div>


                <div class="pro_filed">
                  <div class="form_icon"><img src="{{asset('Influencer/images/call.png')}}"></div>
                  <input type="text" name="phone" id="phone" required value="{{$useralldeatils->phone}}" placeholder="Phone number" pattern="[0-9]*" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                </div>
                @error('phone')
                <span class="text-danger">{{ $message }}</span>
                @enderror

                <div class="pro_filed">
                  @php
                  $dobs = date("m-d-Y", strtotime($useralldeatils->dob))
                  @endphp
                  <div class="form_icon"><img src="{{asset('Influencer/images/date-time.png')}}"></div>
                  <input type="text" name="dob" required id="dob" value="{{ $useralldeatils->dob ? date('m-d-Y', strtotime($useralldeatils->dob )) ? $dobs:old('dob') : $useralldeatils->dob }}" placeholder="Date of Birth">
                  <i class="far fa-calendar-alt"></i>
                </div>
                @error('dob')
                <span class="text-danger">{{ $message }}</span>
                @enderror
               
                <div class="pro_btn1 btn-class">
                  <button type="button" id="edit_btn" class="pro_edit">Edit</button>
                  <button type="submit" id="save_btn" class="pro_save" disabled>Save</button>
                </div>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

  </main>
  <!-- Main-Section -->


  <!-- logout Popup -->
  <div class="modal fade" id="exampleModal_3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"> <i class="fas fa-times-circle"></i></button>

        <div class="modal-body pt-0 pb-5 ">
          <div class="succes_box">
            <img src="{{asset('Influencer/images/logout2.png')}}">
            <h3>Do you want to logout?</h3>
            <div class="cardbtn"><a href="{{route('Userlogout')}}" class="Ok_btn">Ok</a></div>

          </div>
        </div>
      </div>
    </div>
  </div>

  <!--logout Popup-->

</body>

</html>
@endsection

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.3/themes/base/jquery-ui.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" media="all">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
@if (session('success'))
<script>
  toastr.success('Profile updated successfully!');
</script>
@endif


<script>
  $(function() {
    $("#dob").datepicker({
      dateFormat: 'mm-dd-yy',
      maxDate: 0,
      beforeShow: function(input, inst) {
        if ($(input).prop("readonly")) {
            return false; // If input is readonly, don't show calendar
        }
      }
    });

    // Disable manual typing (numbers, letters, paste, backspace, delete)
    $("#dob").on("keydown", function(event) {
      event.preventDefault();
    });

    // Also disable pasting manually
    $("#dob").on("paste", function(event) {
      event.preventDefault();
    });
  });
</script>



<script>
  
// $(document).ready(function() {
//     $('#completeprofile').submit(function(e) {
//         e.preventDefault();

//         var formData = new FormData(this);

//         $.ajax({
//             url: "{{ route('User_My_Profile_Create') }}",
//             type: 'POST',
//             data: formData,
//             processData: false,  // Required for FormData
//             contentType: false,  // Required for FormData
//             success: function(response) {
//                 toastr.success('Profile updated successfully!');
//                 setTimeout(function() {
//                     location.reload(); // Page reload to show updated data
//                 }, 1500);
//             },
//             error: function(xhr, status, error) {
//                 console.error(xhr.responseText);
//                 toastr.error('Something went wrong!');
//             }
//         });
//     });
// });

// $(document).ready(function () {
//     // Pehle sabhi fields ko disable kar do
//     $(".pro_filed input").prop("disabled", true);
//     $("#save_btn").prop("disabled", true);

//     // Edit Button Click
//     $("#edit_btn").click(function () {
//       $(".pro_filed input").prop("disabled", false); // Enable fields
//       $("#save_btn").prop("disabled", false); // Enable Save button
//       $(this).prop("disabled", true); // Disable Edit button
//     });

//     // Save Button Click (With AJAX)
//     $("#completeprofile").submit(function (e) {
//       e.preventDefault();

//       var name = $("input[name='name']").val();
//       var email = $("input[name='email']").val();
//       var phone = $("input[name='phone']").val();
//       var dob = $("input[name='dob']").val();

//       $.ajax({
//         url: "{{ route('User_Profile') }}",
//         type: "POST",
//         data: {
//           _token: $('meta[name="csrf-token"]').attr("content"),
//           name: name,
//           email: email,
//           phone: phone,
//           dob: dob,
//         },
//         success: function (response) {
//           toastr.success("Profile updated successfully!");

//           // Save ke baad fields wapas disable ho jayenge
//           $(".pro_filed input").prop("disabled", true);
//           $("#edit_btn").prop("disabled", false);
//           $("#save_btn").prop("disabled", true);
//         },
//         error: function (xhr, status, error) {
//           console.error(xhr.responseText);
//         },
//       });
//     });
//   });

// $(document).ready(function () {
//     function checkIfProfileIsEmpty() {
//         var name = $("input[name='name']").val().trim();
//         var phone = $("input[name='phone']").val().trim();
//         var dob = $("input[name='dob']").val().trim();

//         // Agar saari fields empty hain toh sab allow kar do
//         if (name === "" && phone === "" && dob === "") {
//             $(".pro_filed input, #image_input").prop("disabled", false);
//             $("#save_btn").prop("disabled", false);
//             $("#edit_btn").show(); // First-time user ko bhi edit button dikhao
//         }
//     }

//     $(".pro_filed input, #image_input").prop("disabled", true);
//     $("#save_btn").prop("disabled", true);
//     $("#edit_btn").show(); // Edit button ko by default show kar do
    
//     checkIfProfileIsEmpty();

//     $("#edit_btn").click(function () {
//         $(".pro_filed input, #image_input").prop("disabled", false);
//         $("#save_btn").prop("disabled", false);
//         $(this).prop("disabled", true);
//     });

//     $("#completeprofile").submit(function (e) {
//         e.preventDefault();

//         var name = $("input[name='name']").val().trim();
//         var email = $("input[name='email']").val().trim();
//         var phone = $("input[name='phone']").val().trim();
//         var dob = $("input[name='dob']").val().trim();

//         var formData = new FormData(this);

//         $.ajax({
//             url: "{{ route('User_My_Profile_Create') }}",
//             type: "POST",
//             data: formData,
//             processData: false,
//             contentType: false,
//             success: function (response) {
//                 toastr.success("Profile updated successfully!");
//                 $(".pro_filed input, #image_input").prop("disabled", true);
//                 $("#edit_btn").prop("disabled", false);
//                 $("#save_btn").prop("disabled", true);
//             },
//             error: function (xhr, status, error) {
//                 console.error(xhr.responseText);
//             },
//         });
//     });

//     $('#upload_icon').click(function (e) {
//         e.preventDefault();
//         if (!$('#image_input').prop("disabled")) {
//             $('#image_input').click();
//         }
//     });

//     $('#image_input').change(function () {
//         var file = this.files[0];
//         var reader = new FileReader();
//         reader.onload = function (e) {
//             $('#preview_image').attr('src', e.target.result);
//         };
//         reader.readAsDataURL(file);
//     });
// });

$(document).ready(function () {
    function checkIfProfileIsEmpty() {
        var name = $("input[name='name']").val().trim();
        var phone = $("input[name='phone']").val().trim();
        var dob = $("input[name='dob']").val().trim();
        var email = $("input[name='email']").val().trim();

        return name === "" || phone === "" || dob === "";
    }

    // Check if this is a first-time user (i.e., all fields are empty)
    var isFirstTimeUser = checkIfProfileIsEmpty();

    if (isFirstTimeUser) {
        $(".pro_filed input:not([name='email']), #image_input").prop("disabled", false);
        $("#edit_btn").show();
        $("#save_btn").prop("disabled", false);
    } else {
        $(".pro_filed input, #image_input").prop("disabled", true);
        $("#edit_btn").show();
        $("#save_btn").prop("disabled", true);
    }

    // Email should be locked if already set
    if ($("input[name='email']").val().trim() !== "") {
        $("input[name='email']").prop("disabled", true);
    }
    
    $("#edit_btn").click(function () {
        $(".pro_filed input:not([name='email']), #image_input").prop("disabled", false);
        $("#save_btn").prop("disabled", false);
    });

    $("#completeprofile").submit(function (e) {
        if (checkIfProfileIsEmpty()) {
            e.preventDefault();
            toastr.error("Please fill all details before saving.");
        }
    });

    $('#upload_icon').click(function (e) {
        e.preventDefault();
        if (!$('#image_input').prop("disabled")) {
            $('#image_input').click();
        }
    });

    $('#image_input').change(function () {
        var file = this.files[0];
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#preview_image').attr('src', e.target.result);
        };
        reader.readAsDataURL(file);
    });
});





</script>

<script>
  $(document).ready(function() {
    var i = 1;
    $('.add-more-input').click(function() {
      i++;
      $('.pro_filed_1data').append('<div class="pro_filed_1" id="row' + i + '"><input type="text" required name="social_site_link[]" placeholder="Enter your instagram Link"><div class="form_icon"><img src="https://tidbidadmin.tgastaging.com/Influencer/images/maki_cross.svg" id="' + i + '" class="w-20 btn_remove"></div></div>');
    });

    $(document).on('click', '.btn_remove', function() {
      var button_id = $(this).attr("id");
      $('#row' + button_id + '').remove();
    });

  });





//   $(document).ready(function() {
//     $('#upload_icon').click(function(e) {
//       e.preventDefault(); // Prevent default action of link
//       $('#image_input').click();
//     });

//     $('#image_input').change(function() {
//       var file = this.files[0];
//       var reader = new FileReader();

//       reader.onload = function(e) {
//         $('#preview_image').attr('src', e.target.result);
//       }

//       reader.readAsDataURL(file);
//     });

//     $('#upload_button').click(function() {
//       var formData = new FormData();
//       formData.append('image', $('#image_input')[0].files[0]);

//       $.ajax({
//         url: 'upload.php', // Your PHP endpoint to handle the upload
//         type: 'POST',
//         data: formData,
//         processData: false,
//         contentType: false,
//         success: function(response) {
//           // Handle success
//           alert('Image uploaded successfully!');
//         },
//         error: function(xhr, status, error) {
//           // Handle errors
//           console.error(error);
//         }
//       });
//     });
//   });
</script>



<script>
  function clearFields() {
    $('.editbutton').hide();
    $('.submitbutton').show();
    document.getElementById('name').readOnly = false;
    document.getElementById('phone').readOnly = false;
    document.getElementById('dob').disabled = false;

  }
</script>

